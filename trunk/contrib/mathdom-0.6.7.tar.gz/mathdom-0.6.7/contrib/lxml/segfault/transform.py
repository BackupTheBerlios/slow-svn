"""
Compile an XHTML look-and-feel into an XSLT to apply to all content pages.

You can also use this from the command-line with this command:

  xsltproc --xinclude themecompiler.xsl themeinputdoc.xml | xsltproc - samples/contentpage.xml 

"""

from lxml import etree
import os

def compileTheme(themeuri, rulesuri):
    """A one-time compilation step on startup

    Arguments:

      - Local file URI for the XHTML theme file

      - Local file URI for the rules, which govern how replacements happen
      """

    # First get the filenames for the support files in this package, 
    # as we might be getting called from some wildly different location
    sitethemedir = os.path.dirname(__file__)
    mergedocfn = os.path.join(sitethemedir, "themeinputdoc.xml")
    themecompilerfn = os.path.join(sitethemedir, "themecompiler.xsl")

    # Try to parse the two URIs, to see if either point to something 
    # bogus.  (We won't get a good message otherwise.)
    try:
	tree = etree.ElementTree(file=themeuri)
    except IOError:
	raise IOError, "The themeuri of %s does not exist" % themeuri
    try:
	tree = etree.ElementTree(file=rulesuri)
    except IOError:
	raise IOError, "The rulesuri of %s does not exist" % rulesuri

    print 1
    # Parse the merge doc
    mergedoc = etree.ElementTree(file=mergedocfn)

    print 2
    # Next, replace the two XInclude references and process xincludes
    xincludes = mergedoc.xpath("//*[@href]")
    xincludes[0].set("href", rulesuri)
    xincludes[1].set("href", themeuri)
    del xincludes
    mergedoc.xinclude()

    # We now have the start of the final XSLT.  The merge doc 
    # contains all the information (rules, theme XHTML) needed. We 
    # now "compile" this into an XSLT that writes XSLT instructions 
    # in the the correct merge points of the XHTML.

    print 3
    themecompilerdoc = etree.ElementTree(file=themecompilerfn)
    print 4
    themecompiler = etree.XSLT(themecompilerdoc)
    del themecompilerdoc
    print 5
    xmldoc = themecompiler.apply(mergedoc)
    del themecompiler
    del mergedoc
    print 6
    compiledtheme = etree.XSLT(xmldoc)
    print 7

    return compiledtheme


def main():
    # Simulate loading theme once at app server launch time
    themeuri = "samples/corporateid.html"
    ruleuri = "samples/themerules.xml"

    # For fun, retrieve the plone.org home page as a theme during the 
    # compilation step (one-time) and use a local merge file.
    #themeuri = "http://plone.org/"
    #ruleuri = "samples/ploneorgrules.xml"

    print 'a'
    compiledtheme = compileTheme(themeuri, ruleuri)

    # As each page comes in, we apply the theme to the page
    print 'b0'
    etree.ElementTree()
    print 'b1'
    etree.ElementTree(file="samples/themerules.xml")
    print 'b'
    contentpage = etree.ElementTree(file="samples/contentpage.xml")
    print 'c'
    result = compiledtheme.apply(contentpage)
    print 'd'
    response = compiledtheme.tostring(result).encode("UTF-8")
    print 'e'

    return response


if __name__ == "__main__":
    r = main()
    print r
