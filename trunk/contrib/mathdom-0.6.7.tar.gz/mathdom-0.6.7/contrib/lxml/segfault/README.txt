========================================
Sitethemes
========================================
----------------------------------------
Applying corporate ID to web content
----------------------------------------

About
-----

In many cases, CMS users customize the main_template.pt for the simple
purpose of applying their existing company look-and-feel.  The
customers add no logic.  They simple re-use their HTML, CSS, JS, etc.

Sitethemes allow customers to do this without touching their existing
HTML files, without introducing any template instructions.  Nor do
they have to modify the "software" templates, which introduces a
maintenance burden when a new release comes out.

Instead, they save their corporate ID to disk, then create a rule
file.  Each rule says which parts of the dynamic results get merged
into which parts of the corporate ID.

What isn't this?  Sitethemes is not a package for generating markup
from data.  It presumes that the page has been generated and is just
about to go out the door.  Some earlier processing step needs to
implement all the logic to gather data and render it into HTML.

This implementation "compiles" the theme for extra performance.  It
does this by doing a one-time generation of an XSLT which is then
applied later.  The theme's XHTML gets modified to include XSLT
instructions during this "compilation" step.  The result is
performance that is quite good.

More explanation:

  http://www.zope.org/Wikis/DevSite/Projects/ComponentArchitecture/SiteThemes

  http://www.zope.org/Members/zopepaul/zopesitethemesdiagram.png

Requirements
------------

  o lxml


Usage
-----

The fastest way to use this is to run:

    python ./transform.py

The module docstring for 'transform.py' also shows how the approach
can be run with no Python and no lxml, simply using the xsltproc
command available for most Unix/Linux/FreeBSD systems (and installable
for Windows, from xmlsoft.org).

To use a different theme and a different rule file, look at the
function "main" in 'transform.py' for how to specify URIs.  There is a
commented-out section that shows how to retrieve a plone.org
look-and-feel and use a different rule file.

Finally, 'transform.py' was setup to be easy to use in an appserver
environment, where finding the mergedoc and compiler XSLT might be
difficult.  The path to read these is set relative to the module's
location.

Note that support is currently hard-wired for appending in script and
link statements from the content document's HEAD node.

One way to really boost performance is to use xml:id attributes in the
content pages that are run through the theme.  With this, the rule
file can have XPath id() functions, rather than traversing the tree to
find the match.  libxml2 optimizes for this.

To Do
-----

1. Lobby for lxml to wire in libxml2's HTML parser.  This would allow
   the theme to be valid HTML without well-formed HTML (e.g. br tags.)

2. Get rid of the spurious namespace declarations in generated output.

3. Allow theme URI and rule file URI to passed as arguments.

4. Implement a way to rewrite all relative links.

5. Consider allowing rule files as Python as well as XML.

6. Add "insertBefore", "appendAfter" support in rule file and
   compiler, so that the script/link support isn't hardwired.

7. Should the rule file allow XPath expressions on both sides, instead
   of just the content document?  Certainly would make for a harder
   compiler.

8. Put back in the check to see if the xinclude URI exists, so the
   traceback reports the correct missing value.

