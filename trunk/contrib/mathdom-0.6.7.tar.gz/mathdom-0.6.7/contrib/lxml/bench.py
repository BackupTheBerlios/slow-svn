"""
A simple speed comparison of SimpleXMLWriter versus lxml for DOM
node creation.

Results for 50 entries:
0.0206758022308 ...XMLWriter average time
0.0190546989441 ...Etree average time

Results for 5000 entries:
1.80105571747 ...XMLWriter average time
0.999091792107 ...Etree average time
"""

from time import time
from lxml.etree import Element, SubElement
import cStringIO
from elementtree.SimpleXMLWriter import XMLWriter

entries = 5000
entry = {
    "id": "1092309103910930",
    "creator": "automaticforthepeople",
    "title": "An entry in the portal_catalog",
    "description": "A longer textual description would go here",
    "created": "12/25/2005 00:00:00 GMT+1",
    "is_folderish": "1",
    "portal_type": "ATFolder",
    "review_state": "published",
    "path": "/Members/automaticforthepeople/junk",
}

def makeXMLWriter():
    f = cStringIO.StringIO()
    tree = XMLWriter(f)
    root = tree.start("catalog")
    for i in range(entries):
        tree.start("entry",
           id=entry['id'],
           creator=entry['creator'],
           title=entry['title'],
           description=entry['description'],
           created=entry['created'],
           is_folderish=entry['is_folderish'],
           portal_type=entry['portal_type'],
           review_state=entry['review_state'],
           )
        tree.end()
    tree.close(root)


def makeEtree0():
    root = Element("catalog")
    for i in range(entries):
        item = Element("entry")
        item.set("id", entry["id"])
        item.set("creator", entry["creator"])
        item.set("title", entry["title"])
        item.set("description", entry["description"])
        item.set("created", entry["created"])
        item.set("is_folderish", entry["is_folderish"])
        item.set("portal_type", entry["portal_type"])
        item.set("review_state", entry["review_state"])
        root.append(item)

def makeEtree1():
    root = Element("catalog")
    for i in range(entries):
        item = SubElement(root, "entry")
        item.set("id", entry["id"])
        item.set("creator", entry["creator"])
        item.set("title", entry["title"])
        item.set("description", entry["description"])
        item.set("created", entry["created"])
        item.set("is_folderish", entry["is_folderish"])
        item.set("portal_type", entry["portal_type"])
        item.set("review_state", entry["review_state"])

def makeEtree2():
    root = Element("catalog")
    for i in range(entries):
        SubElement(root, "entry", entry)


def main():

    repeat = 10

    # Time first
    start1 = time()
    for i in range(repeat):
        makeXMLWriter()
    print (time() - start1)/repeat, "...XMLWriter average time"

    # Time second
    start2 = time()
    for i in range(repeat):
        makeEtree0()
    print (time() - start2)/repeat, "...Etree (orig) average time"

    # Time second
    start3 = time()
    for i in range(repeat):
        makeEtree1()
    print (time() - start3)/repeat, "...Etree (SubElement) average time"

    # Time second
    start4 = time()
    for i in range(repeat):
        makeEtree2()
    print (time() - start4)/repeat, "...Etree (SubElement+dict) average time"

if __name__ == "__main__": main() 
