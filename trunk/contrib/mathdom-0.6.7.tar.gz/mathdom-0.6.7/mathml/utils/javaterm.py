from mathml.termbuilder import tree_converters, InfixTermBuilder

__all__ = [ 'JavaTermBuilder' ]

# BUILDER

class JavaTermBuilder(InfixTermBuilder):
    _OPERATOR_MAP = {
        '='       : '==',
        'abs'     : 'java.lang.Math.abs',
        'acos'    : 'java.lang.Math.acos',
        'asin'    : 'java.lang.Math.asin',
        'atan'    : 'java.lang.Math.atan',
        'atan2'   : 'java.lang.Math.atan2',
        'ceil'    : 'java.lang.Math.ceil',
        'cos'     : 'java.lang.Math.cos',
        'cosh'    : 'java.lang.Math.cosh',
        'degrees' : 'java.lang.Math.toDegrees',
        'exp'     : 'java.lang.Math.exp',
        'floor'   : 'java.lang.Math.floor',
        'log'     : 'java.lang.Math.log',
        'log10'   : 'java.lang.Math.log10',
        'max'     : 'java.lang.Math.max',
        'min'     : 'java.lang.Math.min',
        'pow'     : 'java.lang.Math.pow',
        'radians' : 'java.lang.Math.toRadians',
        'round'   : 'java.lang.Math.round',
        'sin'     : 'java.lang.Math.sin',
        'sinh'    : 'java.lang.Math.sinh',
        'sqrt'    : 'java.lang.Math.sqrt',
        'tan'     : 'java.lang.Math.tan',
        'tanh'    : 'java.lang.Math.tanh'
        }

    _NAME_MAP = {
        u'e'     : u'java.lang.Math.E',
        u'pi'    : u'java.lang.Math.PI',
        }
    map_name = _NAME_MAP.get

    def _handle_name(self, operator, operands, affin):
        name = unicode(str(operands[0]), 'ascii')
        return [ self.map_name(name, name) ]

    def _handle_const_bool(self, operator, operands, affin):
        return [ operands[0] and 'true' or 'false' ]

    def _handle_const_complex(self, operator, operands, affin):
        raise NotImplementedError, "Complex numbers cannot be converted to Java."

    def _handle_interval(self, operator, operands, affin):
        raise NotImplementedError, "Intervals cannot be converted to Java."

    def _handleOP(self, operator, operands, affin):
        if operator == '^':
            return super(JavaTermBuilder, self)._handle(
                "java.lang.Math.pow", operands, affin)
        else:
            return super(JavaTermBuilder, self)._handleOP(
                operator, operands, affin)

tree_converters.register_converter('java', JavaTermBuilder())
